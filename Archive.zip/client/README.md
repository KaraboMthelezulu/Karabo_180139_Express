
<!-- PROJECT LOGO -->
<br />
<p align="center">
  <a href=" ">
    <img src="./src/peerlogo.png" alt="Logo" height="80">
  </a>

  <h3 align="center">Peer: For Students and Teachers</h3>

  <p align="center">
    A scheduling system for students and teachers, which  makes sure that both are organised, informed and punctual. Providing  students with their timetables, allowing them to do peer searches, as well as accesing general information about any student or teacher searched. 
    <br />
  </p>
</p>



<!-- TABLE OF CONTENTS -->
<details open="open">
  <summary><h2 style="display: inline-block">Table of Contents</h2></summary>
  <ol>
    <li>
      <a href="#about-the-project">About Project</a>
      <ul>
        <li><a href="#built-with">Built With</a></li>
        <li><a href="#features">Features</a></li>
      </ul>
    </li>
    <li>
      <a href="#getting-started">Getting Started</a>
      <ul>
        <li><a href="#prerequisites">Prerequisites</a></li>
        <li><a href="#installation">How to Install</a></li>
      </ul>
    </li>
    <li><a href="#concept-ideation">Concept Ideation</a>
      <ul>
        <li><a href="#wireframes">Wireframes</a></li>
        <li><a href="#branding">Branding</a></li>
        <li><a href="#task-flow">Task Flow</a></li>
      </ul>
    </li>
    <li><a href="#contributing">Contributing</a></li>
    <li><a href="#license">License</a></li>
    <li><a href="#contact">Contact</a></li>
    <li><a href="#acknowledgements">Acknowledgements</a></li>
  </ol>
</details>



<!-- ABOUT THE PROJECT -->
## About The Project

Peer:Students and Teachers, is a web based scheduling system, developed using React.js, and Express.js. Which provides students with their timetables, allowing them to do peer searches, as well as accesing general information about any student or teacher searched. 


### Built With

* [React.js](https://reactjs.org/)
* [Express.js](https://expressjs.com/)

### Features

- Viewing students Timetable.
- Customizising their Profile.
- Dashboard that allows for easy acess to navigate through system.


<!-- GETTING STARTED -->
## Getting Started

Due to storage purposes ypou will have to install some dependancies to run 'Peer'

Open the project folder using Visual Studio Code, open the terminal. 

Once you have that opened up , we willl create two seprate terminal, one housing the server side and the other housing the client side. 

### First Terminal page
<br>
Server

  ```sh
  cd server
  ```

### Second Terminal page
<br>
Client

  ```sh
  cd client
  ```
 
<br>

Now you will npm install on both terminals

* npm
```sh
  npm install
  ```

There after we will go on to creating a `package.json` file:
<br>
npm
```sh
  npm init —y
  ```

### Installation
<br>
 <b>Express.js</b><br>
 
Express js is what we have used for our Backend

<br>

Install on your 'server' terminal
   ```sh
  nnpm install express
   ```
<br><br>
<b>React.js</b><br>
React is what we have used for our front-end 
<br>

Install on your client terminal
   ```sh
  npm create-react-app
   ```

Then you'll also add a few more React relates modeules to your client terminal
   ```sh
  npm i react-router bootstrap reactstrap uuid react-router-dom
  ```  

<br>


## Concept Ideation

### Wireframes

<img src="./src/GroupOne.png" alt="Logo" width="49%" height="" style="float:left, margin-left:10px;">

<img src="./src/GroupTwo.png" alt="Logo" width="49%" height="" style="float:right">

<img src="./src/GroupThree.png" alt="Logo" width="49%" height="" style="float:left, margin-left:10px;">

<img src="./src/GroupFour.png" alt="Logo" width="49%" height="" style="float:right">

### Task Flow

<img src="./src/Timetable.png" alt="Logo" width="80%" height="" style="float:left, margin-left:10px;">

### Moodboard

<img src="./src/Moodboard.png" alt="Logo" width="80%" height="" style="float:left, margin-left:10px;">

<!-- LICENSE -->
## License

Distributed under the MIT License. See `LICENSE` for more information.



<!-- CONTACT -->
## Contact

Karabo

Project Link: [ https://github.com/KaraboMthelezulu/Node.js-Chatroom.git ]( https://github.com/KaraboMthelezulu/Node.js-Chatroom.git )


<!-- ACKNOWLEDGEMENTS -->
## Acknowledgements

* (https://www.freepik.com/vectors/people)
* (https://icons8.com/icon/11234/planner)
* (https://icons8.com/icon/33872/cat-profile)
* (https://www.freepik.com/vectors/school)
