import logo from '../peerlogo2.png';
import './login.css';

import React from 'react';
import {Form, FormGroup, Label, Input, Button} from 'reactstrap';

export const login = () => {

  return (
    <Form className="NameForm" onSubmit={this.handleSubmit}>
      <FormGroup>
    <img src={logo} className="Peer-logo2" alt="logo" /><br></br>
        <Input type="text" name= "username" placeholder="Username"/>
      <br></br>
        <Input type="text" name= "password" placeholder="Password"/>
      <br></br>
      </FormGroup>
      <Button type="submit"> SUBMIT</Button>
    </Form>
  );
}

export default login;