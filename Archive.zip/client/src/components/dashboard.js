import logo from './peerlogo.png';
import './dashboard.css';
import one from './one.png'
import planner from './planner.png'
import profile from './profile.png'

import {Link, useHistory} from 'react-router-dom';




export const dashboard = () => {
  return (

  <div className = "Base">
    <div className = "sideNav">
      <div className = "logo">
      <img src={logo} className="App-logo" alt="logo" />
      </div>
        <br></br>
        <br></br>

        <div className = "tags">
          <ul>
            <li className = "active">
              <a href = " #" >Dashboard</a>
            </li>

            <li>
            <a href = " #" >Timtable</a>
            </li>

            <li>
              <a href = "#">Profile</a>
            </li>
          </ul>
        </div>

        <button> 
        <a className="button" href="https://reactjs.org">
        SIGN OUT
        </a>
        
      </button>
    </div>

   

    <div className = "body">


      <div className = "welcomeUser">
        <div className = "textContainer">
        <h1>Welcome Back Ian</h1>
        <h2> 22 August 2020</h2>
        <p className = "timeText">14:00pm</p>
        </div>

        <div className ="imageOne">
        <img src={one} className="one" alt="logo" />
        </div>

      </div>
   
    

    <div className = "quickAccess">
      <h2> Quick Access</h2>
      <br></br>
      <div className = "containerTwo">
        <div className = "blockOne">
        <h2>Timetable</h2>
        <img src={planner} className="icons" alt="logo" />
        <p className = "Text">Timetable for this week have <br></br>been released</p>
        </div>
        <div className = "blockTwo">
        <h2>Profile</h2>
        <img src={profile} className="icons" alt="logo" />
        <p className = "Text">Make that your sure profile <br></br>is up to date</p>
        </div>
      </div>
    </div>
    </div>
  
  </div>
  );
}

export default dashboard;
