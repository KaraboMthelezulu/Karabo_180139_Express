import logo from './peerlogo.png';
import './App.css';
import two from './two.png'




export const timetable = () => {
  return (

  <div className = "Base">
    <div className = "sideNav">
      <div className = "logo">
      <img src={logo} className="App-logo" alt="logo" />
      </div>
        <br></br>
        <br></br>

        <div className = "tags">
          <ul>
            <li>
              <a href = " #" >Dashboard</a>
            </li>

            <li className = "active">
              <a href = "#" >Timetable</a>
            </li>

            <li>
              <a href = "#">Profile</a>
            </li>
          </ul>
        </div>

        <button> 
        <a className="button" href="https://reactjs.org">
        SIGN OUT
        </a>
        
      </button>
    </div>

   

    <div className = "body">


      <div className = "welcomeUser">
        <div className = "textContainer">
        <h1>Your Weekly Timetable</h1>
        <p className = "timeText">Gr 10</p>
        </div>

        <div className ="imageOne">
        <img src={two} className="one" alt="logo" />
        </div>

      </div>
   
    

    <div className = "quickAccess">
      <h2></h2>
      <br></br>
      
      <div className = "weekDays">

<div className = "days">
<h2 className = "subjectText">Monday</h2>
</div>

<div className = "days">
<h2 className = "subjectText">Tuesday</h2>
</div>

<div className = "days">
<h2 className = "subjectText">Wednesday</h2>
</div>

<div className = "days">
<h2 className = "subjectText">Thurdsay</h2>
</div>

<div className = "days">
<h2 className = "subjectText">Friday</h2>
</div>

</div>
<br></br>
<br></br>


      <div className = "containerTwo">

        <div className = "blockOne">
        <h2 className = "subjectText">History</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockTwo">
        <h2 className = "subjectText">Physical Science</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockOne">
        <h2 className = "subjectText">Accounting</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockTwo">
        <h2 className = "subjectText">Maths</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockOne">
        <h2 className = "subjectText">Afrikaans</h2>
        <p className = "Text">Teacher</p>
        </div>

       </div>
      <br></br>
       <div className = "containerTwo">

        <div className = "blockOne">
        <h2 className = "subjectText">Afrikaans</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockTwo">
        <h2 className = "subjectText">History</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockOne">
        <h2 className = "subjectText">English</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockTwo">
        <h2 className = "subjectText">Physical Science</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockOne">
        <h2 className = "subjectText">Maths</h2>
        <p className = "Text">Teacher</p>
        </div>

       </div>
       
       <br></br>
       <div className = "containerTwo">

        <div className = "blockOne">
        <h2 className = "subjectText">Physical Science</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockTwo">
        <h2 className = "subjectText">Maths</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockOne">
        <h2 className = "subjectText">Afrikaans</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockTwo">
        <h2 className = "subjectText">History</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockOne">
        <h2 className = "subjectText">English</h2>
        <p className = "Text">Teacher</p>
        </div>

       </div>
       <br></br>

       <div className = "breakcontainer">
       <h1>Break</h1>
       </div>
       <br></br>

       <div className = "containerTwo">

        <div className = "blockOne">
        <h2 className = "subjectText">Maths</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockTwo">
        <h2 className = "subjectText">Afrikaans</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockOne">
        <h2 className = "subjectText">Maths</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockTwo">
        <h2 className = "subjectText">Accounting</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockOne">
        <h2 className = "subjectText">Accounting</h2>
        <p className = "Text">Teacher</p>
        </div>

       </div>
       <br></br>

       <div className = "containerTwo">

        <div className = "blockOne">
        <h2 className = "subjectText">English</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockTwo">
        <h2 className = "subjectText">English</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockOne">
        <h2 className = "subjectText">Physical Science</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockTwo">
        <h2 className = "subjectText">Afrikaans</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockOne">
        <h2 className = "subjectText">Physical Science</h2>
        <p className = "Text">Teacher</p>
        </div>

       </div>
       <br></br>

       <div className = "containerTwo">

        <div className = "blockOne">
        <h2 className = "subjectText">Accounting</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockTwo">
        <h2 className = "subjectText">Accounting</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockOne">
        <h2 className = "subjectText">English</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockTwo">
        <h2 className = "subjectText">English</h2>
        <p className = "Text">Teacher</p>
        </div>

        <div className = "blockOne">
        <h2 className = "subjectText">History</h2>
        <p className = "Text">Teacher</p>
        </div>

       </div>
       <br></br>

       
    </div>
    </div>
  
  </div>
  );
}

export default timetable;
