import logo from './peerlogo.png';
import './App.css';
import three from './three.png'




export const profile = () => {
  return (

  <div className = "Base">
    <div className = "sideNav">
      <div className = "logo">
      <img src={logo} className="App-logo" alt="logo" />
      </div>
        <br></br>
        <br></br>

        <div className = "tags">
          <ul>
            <li>
              <a href = " #" >Dashboard</a>
            </li>

            <li>
              <a href = "#" >Timetable</a>
            </li>

            <li className = "active">
              <a href = "#">Profile</a>
            </li>
          </ul>
        </div>

        <button> 
        <a className="button" href="https://reactjs.org">
        SIGN OUT
        </a>
        
      </button>
    </div>

   

    <div className = "body">


      <div className = "welcomeUser">
        <div className = "textContainer">
        <h1>Ian Reid</h1>
        <h2>Gr 10</h2>
        <p className = "timeText">Class Captain , Drum Majorette</p>
        </div>

        <div className ="imageOne">
        <img src={three} className="three" alt="logo" />
        </div>

      </div>
   
    

    <div className = "quickAccess">
      <h2></h2>
      <br></br>
      
      <div className = "weekDays">

<div className = "days">
<h2 className = "subjectText">Subjects Taken</h2>
</div>

</div>
<br></br>
<br></br>


      <div className = "containerTwo">

        <p className = "Text">English</p>
        <br></br>
        <p className = "Text">Afrikaans</p>
        <br></br>
        <p className = "Text">History</p>
        <br></br>
        <p className = "Text">Mathematics</p>
        <br></br>
        <p className = "Text">Physical Science</p>
        <br></br>
        <p className = "Text">Accounting</p>
        <br></br>

        

       </div>
      

       
    </div>
    </div>
  
  </div>
  );
}

export default profile;
