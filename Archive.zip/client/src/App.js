import React from 'react';
import logo from './peerlogo.png';
import "./App.css"


function App() {
  return (
    //<div className="App">
      //<header className="App-header">
      //  <img src={logo} className="App-logo" alt="logo" />
      //  <p>
      //    Edit <code>src/App.js</code> and save to reload.
      //  </p>
      //  <a
      //    className="App-link"
      //   href="https://reactjs.org"
      //   target="_blank"
      //    rel="noopener noreferrer"
      //  >
      //    Learn React
      //  </a>
      //</header>
   // </div>

   <div className="App">
      <header className="App-header">
        <img src={logo} className="Peer-logo" alt="logo" />
        <br></br>
    <p className="q1">Are you a:</p>
    <div className="Container-one">
      <div className="student">
        <button> 
        <a
        className="button"
           href="https://reactjs.org"
        >
        Student
        </a>
        </button>
      </div>
      <div className="OR">
      <p className="q2">OR</p>
      </div>
      <div className="teacher">
      <button> 
        <a
        
        className="button"
           href="https://reactjs.org"
        >
        Teacher
        </a>
        
      </button>
      </div>
    </div> 
    
    </header>
    </div>
  );
}

export default App;
